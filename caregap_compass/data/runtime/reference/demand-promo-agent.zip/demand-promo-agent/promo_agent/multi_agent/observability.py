# multi_agent/observability.py
import os
import uuid
import structlog
import logging
import sys

from opentelemetry import metrics, trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.cloud_monitoring import CloudMonitoringMetricsExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter
from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from dotenv import load_dotenv

# --- 1. ROBUST IMPORT BLOCK (Fixes ImportError) ---
# We use a cascade to find where 'View' lives in your specific library version.

try:
    # 1. Try importing everything from the .view submodule (Most likely for your version)
    from opentelemetry.sdk.metrics.view import View, ExplicitBucketHistogramAggregation, InstrumentSelector
except ImportError:
    try:
        # 2. Try .view but without InstrumentSelector (Intermediate versions)
        from opentelemetry.sdk.metrics.view import View, ExplicitBucketHistogramAggregation
        InstrumentSelector = None
    except ImportError:
        # 3. Fallback to top-level .metrics (Very old versions)
        from opentelemetry.sdk.metrics import View, ExplicitBucketHistogramAggregation
        InstrumentSelector = None
# --------------------------------------------------

load_dotenv()
instance_id = str(uuid.uuid4())

# --- HELPER: TRACE CONTEXT INJECTION ---
def add_google_trace_context(logger, log_method, event_dict):
    span = trace.get_current_span()
    if span != trace.INVALID_SPAN:
        ctx = span.get_span_context()
        if ctx.is_valid:
            project_id = os.environ.get("GOOGLE_CLOUD_PROJECT", "unknown-project")
            event_dict["logging.googleapis.com/trace"] = f"projects/{project_id}/traces/{format(ctx.trace_id, '032x')}"
            event_dict["logging.googleapis.com/spanId"] = format(ctx.span_id, "016x")
            event_dict["trace_sampled"] = ctx.trace_flags.sampled
    return event_dict

# --- HELPER: SEVERITY MAPPING ---
def add_severity_for_google_cloud(logger, log_method, event_dict):
    if "level" in event_dict:
        event_dict["severity"] = event_dict["level"].upper()
    return event_dict

def configure_centralized_telemetry():
    
    resource = Resource.create({
        "service.name": "promo-agent-service", 
        "service.instance.id": instance_id, 
        "service.namespace": "vertex-ai-agents"
    })
    
    # 3. Configure Metrics

    try:
        project_id = os.environ.get("GOOGLE_CLOUD_PROJECT")
        if not project_id:
            import google.auth
            _, project_id = google.auth.default()
        
        print(f"🔎 [Telemetry] Initializing Metrics for Project ID: {project_id}")

        metric_exporter = CloudMonitoringMetricsExporter(
            add_unique_identifier=False, 
            prefix="custom.googleapis.com",
            project_id=project_id 
        )
        
        reader = PeriodicExportingMetricReader(metric_exporter, export_interval_millis=10000)

        # --- 2. ROBUST VIEW CONFIGURATION ---
        # Explicit bucket boundaries (0.1s to 10s) to fix the "Solid Block" heatmap issue.
        custom_boundaries = [0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0]

        if InstrumentSelector:
            # Modern SDK Way
            exemplar_view = View(
                instrument_selector=InstrumentSelector(type="histogram"),
                aggregation=ExplicitBucketHistogramAggregation(boundaries=custom_boundaries)
            )
        else:
            # Legacy SDK Way (Backwards compatibility)
            exemplar_view = View(
                instrument_name="*", # Wildcard for all histograms
                aggregation=ExplicitBucketHistogramAggregation(boundaries=custom_boundaries)
            )

        provider = MeterProvider(
            resource=resource, 
            metric_readers=[reader],
            views=[exemplar_view] 
        )
        metrics.set_meter_provider(provider)
        print("✅ [Telemetry] Metrics Configured Successfully")

    except Exception as e:
        print(f"⚠️ [Telemetry] Failed to Initialize Metrics.")
        print(f"   Error details: {e}")

     # --- 3. LOGGING CONFIGURATION ---
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    
    if root_logger.handlers:
        for handler in root_logger.handlers:
            handler.setLevel(logging.INFO)
            handler.setFormatter(logging.Formatter("%(message)s"))
    else:
        logging.basicConfig(
            level=logging.INFO,
            format="%(message)s",
            stream=sys.stdout
        )

    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.stdlib.add_log_level,
            add_google_trace_context,
            add_severity_for_google_cloud,
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )