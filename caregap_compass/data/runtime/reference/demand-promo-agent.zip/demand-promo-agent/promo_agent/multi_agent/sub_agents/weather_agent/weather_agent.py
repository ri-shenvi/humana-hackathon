# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import structlog
import httpx
import time
import random
from google.adk.agents import LlmAgent
from google.adk.tools import ToolContext
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StreamableHTTPConnectionParams
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse, LlmRequest
from google.genai import types
from typing import Optional
from google.cloud import secretmanager
import google_crc32c
from google.cloud import modelarmor_v1
import google.auth
import google.auth.transport.requests
import google.oauth2.id_token
from opentelemetry import trace, metrics
from ...callbacks.mcp_token import MCPToolsetWithToolAccess
from ...callbacks.mcp_token import init_MCP_tools
from pathlib import Path
from dotenv import load_dotenv
from functools import lru_cache # <--- 1. Import lru_cache

# --- CONFIGURE OBSERVABILITY ---
logger = structlog.get_logger()
tracer = trace.get_tracer(__name__)
meter = metrics.get_meter(__name__)

# --- Environment Setup ---
env_path = Path(__file__).resolve().parents[2] / '.env'
load_dotenv(dotenv_path=env_path)

MCP_URL = os.getenv("MCP_URL")
MCP_AUD = os.getenv("MCP_AUD")
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
MAPS_SECRET_ID = os.getenv("MAPS_SECRET_ID")
MAPS_SECRET_VERSION = os.getenv("MAPS_SECRET_VERSION")
#request_tracker = {"count": 0, "last_reset": time.time()}
CHAOS_TRIGGER_CITIES = ["miami", "las vegas", "detroit", "boston", "denver"]
# Weather Agent specific prompt
WEATHER_SYSTEM_PROMPT = """
You are the Weather Agent.
Your ONLY job is to retrieve weather data for a specific location and day using the `get_weather` tool.

INSTRUCTIONS:
1. **Extract Entities**: Identify the `city` and `day` from the user's request.
2. **Force Tool Call**: You MUST call the `get_weather` tool immediately. Do not write any conversational text like "Checking now...".
3. **Handle Missing Data**:
   - If the City is missing, ask for it.
   - If the Time is missing, default to "today".
4. call the get_weather tool only 
OUTPUT:
Output only the weather details in this format:

**Weather Agent:**
If tool call is successful:
Weather for [insert_city] on [day_of_week]: 
High: [insert_high] 
Low: [insert_low] 
Wind: [insert_wind] 
Forecast: [insert_forecast][newline][newline]
- If tool fails: output "WEATHER_UNAVAILABLE".
"""

def get_tools():
    """Gets tools from the MCP Server."""
   
    
    with trace.get_current_span() as span:
       
        span.set_attribute("gen_ai.tool.name", "mcp_tool")
        logger.info("environment_config_check", 
            mcp_url=MCP_URL, 
            mcp_aud=MCP_AUD, 
            project_id=PROJECT_ID, 
            maps_secret_id=MAPS_SECRET_ID
        )

        if not all([MCP_URL, MCP_AUD, PROJECT_ID]):
            logger.error("missing_environment_variables")
            raise EnvironmentError("Missing required environment variables in .env file.")
        try:
            connection_params = StreamableHTTPConnectionParams(
                url=MCP_URL
            )
            tools = MCPToolsetWithToolAccess(
                connection_params=connection_params,
                tool_set_name="get_weather",
                errlog=None 
            )
            logger.info("mcp_toolset_created")
            return tools
        except Exception as e:
            logger.error("mcp_toolset_failed", error=str(e))
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            raise

def access_secret_version(project_id: str, secret_id: str, version_id: str) -> str:
    """Access the payload for the given secret version if one exists."""
    start_time = time.time()
    with trace.get_current_span() as span:
        span.set_attribute("gen_ai.tool.name", "Secret_Version")
        
        try:
            client = secretmanager.SecretManagerServiceClient()

            if secret_id.startswith("projects/"):
                name = secret_id
            else:
                name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"
            
            # Access the secret version.
            response = client.access_secret_version(request={"name": name})

            # Verify payload checksum.
            crc32c = google_crc32c.Checksum()
            crc32c.update(response.payload.data)
            if response.payload.data_crc32c != int(crc32c.hexdigest(), 16):
                error_msg = "Secret Manager data corruption detected (CRC32C checksum failed)."
                logger.error(error_msg)
                span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
                duration_ms = (time.time() - start_time) * 1000
                return None
            
            logger.info("secret_accessed_successfully", secret_name=name)
            duration_ms = (time.time() - start_time) * 1000
            return response.payload.data.decode("UTF-8")

        except Exception as e:
            logger.error("secret_access_failed", error=str(e), exc_info=True)
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            duration_ms = (time.time() - start_time) * 1000
            raise

    
@lru_cache(maxsize=1)
def get_cached_maps_key():
    """Wrapper to cache the Secret Manager response."""
    with trace.get_current_span() as span:
        span.set_attribute("gen_ai.tool.name", "get_cached_map_keys")
        logger.info("fetching_maps_secret_from_gsm_cache_miss")
        return access_secret_version(PROJECT_ID, MAPS_SECRET_ID, MAPS_SECRET_VERSION)

async def get_coordinates_from_city(tool_context: ToolContext, city: str) -> dict:
    """Gets the latitude and longitude for a given city."""
    
    # Trace the Geocoding operation
    with trace.get_current_span() as span:
        span.set_attribute("gen_ai.tool.name", "get_coordinates")
        span.set_attribute("gen_ai.tool.system", "google_maps_api")
        span.set_attribute("gen_ai.tool.params.city", city)
        log = logger.bind(city=city)
     
        if city.lower() in CHAOS_TRIGGER_CITIES:
            with tracer.start_as_current_span("mcp_weather") as child_span:
                latency = random.uniform(60.0, 120.0) 
                logger.warning("Introducing latency", latency_seconds=latency)
            
                # Record attributes on the child span for filtering in Task 3
                child_span.set_attribute("debug.latency_s", latency)
            
                # The sleep is now inside the nested span and will be timed
                time.sleep(latency)
            
                # Mark the child span as successful
                #child_span.set_status(trace.Status(trace.StatusCode.OK))
                child_span.set_status(trace.Status(trace.StatusCode.OK, "Simulated Latency Bottleneck"))
        
        try:
            # --- 3. UPDATED: USE CACHED KEY ---
            api_key = get_cached_maps_key()

            # 2. Call Google Maps API
            async with httpx.AsyncClient() as client:
                with tracer.start_as_current_span("http_google_maps_geocode"):
                    response = await client.get(
                        "https://maps.googleapis.com/maps/api/geocode/json",
                        params={"address": city, "key": api_key},
                    )
                
                response.raise_for_status()
                data = response.json()

                if data["status"] == "OK":
                    location = data["results"][0]["geometry"]["location"]
                    
                    # Log & Metric
                    log.info("coordinates_found", lat=location["lat"], lng=location["lng"])
                    
                    
                    return {"lat": location["lat"], "lng": location["lng"]}
                else:
                    error_msg = f"Could not get coordinates for {city}. Status: {data['status']}"
                    log.error("geocoding_failed", status=data['status'])
                    span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
                    
                    raise ValueError(error_msg)

        except Exception as e:
            log.error("get_coordinates_exception", error=str(e), exc_info=True)
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            raise

def get_weather_agent():
    tools = get_tools()
    weather_agent = LlmAgent(
        name="WeatherAgent",
        model="gemini-2.5-flash",
        instruction=WEATHER_SYSTEM_PROMPT,
        output_key="weather",
        tools=[tools, get_coordinates_from_city],
        before_agent_callback=init_MCP_tools
    )  
    return weather_agent

weather_agent = get_weather_agent()