import structlog
import random
import time
from opentelemetry import trace
from google.adk.agents import Agent
from google.adk.tools import google_search, AgentTool
from google.adk.agents.callback_context import CallbackContext 

logger = structlog.get_logger().bind(agent_name="GoogleSearchAgent")
tracer = trace.get_tracer(__name__)

# --- CONFIGURATION ---
CHAOS_TRIGGER_CITIES = ["miami", "las vegas", "detroit"]

# --- SYSTEM PROMPT ---
GOOGLE_SEARCH_SYSTEM_PROMPT = f"""
You are the **Google Search Supervisor**.
Your job is to find local events and information for a specific city.

INSTRUCTIONS:
1. **Extract Entities**: Identify the 'city' from the user's request.
2. **Tool Selection**:
   - If the city is one of: {", ".join(CHAOS_TRIGGER_CITIES)}, you MUST call `chaos_search_tool` and pass both the 'query' and the 'city'.
   - For ALL other cities, use the standard `search_tool`.

- If `chaos_search_tool` fails, DO NOT RETRY.
- YOUR FINAL OUTPUT MUST BE: "Search failed due to backend outage."
"""

# --- CHAOS WORKER ---
def chaos_search_tool_function(query: str, city: str):
    """
    Special search tool. USE THIS ONLY for: Miami, Las Vegas, Detroit.
    """
    
    with trace.get_current_span() as span:
        span.set_attribute("gen_ai.tool.name", "chaos_google_search")
        span.set_attribute("gen_ai.tool.params.city", city)
        logger.info("chaos_search_triggered", city=city, query=query)

        # Simulate Latency
        delay = random.uniform(0.5, 3.0)
        time.sleep(delay)
        # Always Fail for Chaos Cities
        error_msg = "503 Service Unavailable: Search backend is shedding load."
        logger.error("search_backend_failure", error=error_msg, duration_s=delay)
        span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
        
        return f"TOOL_ERROR: {error_msg}"

# Define the Child Agents
standard_search_agent = Agent(
    name="StandardSearchWorker",
    model="gemini-2.5-flash",
    instruction="You are a standard search assistant. Use Google Search to answer.",
    tools=[google_search], 
)

chaos_search_agent = Agent(
    name="ChaosWorker",
    model="gemini-2.5-flash",
    instruction="You are a chaos simulator. Execute the tool provided.",
    tools=[chaos_search_tool_function], 
)

# Wrap them as tools for the Parent
search_tool_wrapper = AgentTool(agent=standard_search_agent)
chaos_tool_wrapper = AgentTool(agent=chaos_search_agent)

# PARENT AGENT FACTORY
def create_search_agent():
    logger.info("initializing_agent")
    
    agent = Agent(
        name="GoogleSearchAgent",
        model="gemini-2.5-flash",
        instruction=GOOGLE_SEARCH_SYSTEM_PROMPT,
        tools=[search_tool_wrapper, chaos_tool_wrapper],
        output_key="search_result"
    )
    
    return agent

google_search_agent = create_search_agent()