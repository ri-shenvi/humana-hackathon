# Copyright 2025 Google LLC
import structlog
from opentelemetry import trace, metrics
from google.adk.agents import LlmAgent
from google.adk.tools import ToolContext
from google.adk.agents.callback_context import CallbackContext
from google import genai
from google.genai import types
from google.genai.types import GenerateImagesConfig

# --- CONFIGURE OBSERVABILITY ---
logger = structlog.get_logger()
tracer = trace.get_tracer(__name__)

# --- TOOL DEFINITION ---
async def generate_image(tool_context: ToolContext, prompt: str) -> dict:
    with tracer.start_as_current_span("tool_generate_image") as span:
        span.set_attribute("genai.model", "imagen-3.0-fast-generate-001")
        span.set_attribute("genai.prompt", prompt)
        log = logger.bind(tool="generate_image", prompt_snippet=prompt[:50])
        log.info("image_generation_start")

        try:
            client = genai.Client()
            output_file = "promo-image.png"

            image_response = client.models.generate_images(
                model="imagen-4.0-fast-generate-001",
                prompt=prompt,
                config=GenerateImagesConfig(
                    image_size="2k"),
            )
            generated_image = image_response.generated_images[0]
            
            artifact_part = types.Part(
                inline_data=types.Blob(
                    data=generated_image.image.image_bytes, 
                    mime_type="image/png"
                )
            )
            artifact_version = await tool_context.save_artifact( 
                filename=output_file, 
                artifact=artifact_part 
            )
            log.info("image_generation_success", artifact_id=str(artifact_version))
            return {"status": "success", "image_artifact": artifact_version, "used_prompt": prompt}

        except Exception as e:
            error_message = f"Failed to generate/save image: {str(e)}"
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
            log.error("image_generation_failed", error=error_message, exc_info=True)
            return {"status": "error", "error_message": error_message}

# --- SYSTEM PROMPT ---
MARKETING_SYSTEM_PROMPT = """
You are a marketing agent. Your goal is to create a compelling visual advertisement.
Based on the provided inventory details in {inventory}, generate a single, high-quality image that would be suitable for a promotional campaign.
Use the `generate_image` tool to create the visual. The description you provide to the tool should be a rich, detailed prompt that captures the essence of the product.
** Critical: Must Include the product name and an advertising slogan prominently in the image itself. **

Your response MUST look like this:

**Marketing Agent:**

Product: {Product Name}
Slogan: {The slogan used in the image}\n\n
"""


# --- AGENT DEFINITION ---
marketing_agent = LlmAgent(
    name="MarketingAgent",
    model="gemini-2.5-flash",
    instruction=MARKETING_SYSTEM_PROMPT,
    output_key="promo",
    tools=[generate_image]
)