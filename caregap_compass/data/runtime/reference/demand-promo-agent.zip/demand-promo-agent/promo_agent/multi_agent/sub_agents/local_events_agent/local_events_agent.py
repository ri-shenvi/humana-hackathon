

import structlog
from typing import Optional, Any
from opentelemetry import trace, metrics
from google.adk.agents import LlmAgent
from google.adk.tools.agent_tool import AgentTool

from ..google_search_agent.google_search_agent import google_search_agent
from ...callbacks.modelarmor import model_armor_sanitize_response
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse

# --- CONFIGURE OBSERVABILITY ---
logger = structlog.get_logger()
tracer = trace.get_tracer(__name__)

# --- ERROR DEFINITION ---
class UpstreamServiceError(Exception):
    """Raised when a child agent/tool reports a critical backend failure."""
    pass

# --- REPORT FAILURE ---
def fail_on_upstream_outage(llm_response: LlmResponse, **kwargs: Any) -> Optional[LlmResponse]:
    """
    Inspects the final response from the LLM.
    If the LLM reports a backend outage, raises an exception.
    """
    response_text = ""
    #Check if we have content and parts
    if llm_response and llm_response.content and llm_response.content.parts:
        part = llm_response.content.parts[0]

        if part.text:
            response_text = part.text.strip()
    
    # Define the failure signatures
    failure_signatures = [
        "Search failed due to backend outage",
        "TOOL_ERROR",
        "503 Service Unavailable"
    ]
    
    # Check for failure (only if we actually found text)
    if response_text and any(sig in response_text for sig in failure_signatures):
        
        logger.error("upstream_dependency_failure", 
                     agent="LocalEventsAgent", 
                     error=response_text)
        
        current_span = trace.get_current_span()
        if current_span:
            current_span.set_status(trace.Status(trace.StatusCode.ERROR, response_text))
        
        raise UpstreamServiceError(f"Critical Upstream Failure: {response_text}")
    return llm_response
# --- SYSTEM PROMPT ---

LOCAL_EVENTS_SYSTEM_PROMPT = """
You are an agent that performs real-time web searches for local events.

Use the google_search_agent tool to get local events for a given city.

If no city is provided, assume that the city is Seattle.

Output only a list of up to 10 events in this format:

**Local Events Agent:**

Events for [city] on [day of week]:

- [event_name]: [description]
- [event_name]: [description]
...
[newline][newline]
\n\n

"""


# --- AGENT DEFINITION ---
local_events_agent = LlmAgent(
    name="LocalEventsAgent",
    model="gemini-2.5-flash",
    instruction=LOCAL_EVENTS_SYSTEM_PROMPT,
    output_key="local_events",
    tools=[
        # Wraps the Google Search Agent as a callable tool for this agent
        AgentTool(google_search_agent)
    ],
    after_model_callback=[model_armor_sanitize_response, fail_on_upstream_outage ]
)
