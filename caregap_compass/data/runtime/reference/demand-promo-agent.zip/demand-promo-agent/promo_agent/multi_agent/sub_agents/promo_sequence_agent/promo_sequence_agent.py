# Copyright 2025 Google LLC
# Licensed under the Apache License, Version 2.0.

import time
import structlog 
from typing import AsyncGenerator
from opentelemetry import trace, metrics, context
from google.adk.agents import BaseAgent
from google.adk.agents import InvocationContext
from google.adk.events.event import Event
from google.adk.utils.context_utils import Aclosing
from google.genai import types
from ..weather_agent.weather_agent import weather_agent
from ..local_events_agent.local_events_agent import local_events_agent
from ..inventory_agent.inventory_agent import inventory_agent
from ..marketing_agent.marketing_agent import marketing_agent
from ..local_events_agent.local_events_agent import UpstreamServiceError

# --- CONFIGURE OBSERVABILITY ---
logger = structlog.get_logger()
tracer = trace.get_tracer(__name__)
meter = metrics.get_meter(__name__)

# 2. Define Metrics
sub_agent_duration_histogram = meter.create_histogram(
    name="adk.agent.promo.sub_agent_duration_v3",
    description="Duration of sub-agent execution",
    unit="s"
)

sub_agent_failure_counter = meter.create_counter(
    name="adk.agent.promo.sub_agent_failure_v3",
    description="Count of sub-agent crashes",
    unit="{failure}"
)

KNOWN_FAILURE_PHRASES = [
    "Search failed due to backend outage", 
    "ABORT: Upstream Search Service is Down",
    "TOOL_ERROR"
] 

class ConditionalSequentialAgent(BaseAgent):
    """
    An agent that runs its sub-agents in sequence, but stops if a stop signal
    is found in the state.
    """
  
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        
        for agent_id, sub_agent in enumerate(self.sub_agents):
            skip_newline = False
            
            # Start the trace span for this specific sub-agent
            with tracer.start_as_current_span(f"promo_step_{sub_agent.name}") as span:
                active_context = context.get_current()
                span.set_attribute("gen_ai.agent.name", sub_agent.name)
                span.set_attribute("gen_ai.agent.id", str(agent_id))
                
                # --- INITIALIZE REASONING CAPTURE ---
                # This will be used for the 'thought' attribute
                captured_thought = ""
                span.set_attribute("gen_ai.agent.action", f"Executing {sub_agent.name} reasoning chain")
                
                log = logger.bind(
                    agent_name=sub_agent.name, 
                    agent_id=agent_id,
                    step="sequence_execution"
                )

                # 1. Check for Stop Signals
                request_stop = ctx.session.state.get("request_stop_signal_found", False)
                response_stop = ctx.session.state.get("response_stop_signal_found", False)

                if request_stop or response_stop:
                    log.warning("stop_signal_detected", reason="security_policy_violation")
                    span.set_status(trace.Status(trace.StatusCode.ERROR, "Blocked by Security"))
                    span.set_attribute("gen_ai.thought", "Reasoning stopped: Security policy violation detected.")
                    skip_newline = True
                    break 

                # 2. Marketing Agent Skip Logic
                if sub_agent.name == "MarketingAgent":
                    inventory_data = ctx.session.state.get("inventory")
                    if not inventory_data or "NO_INVENTORY_FOUND" in inventory_data:
                        log.info("skipping_agent", reason="no_inventory_data_found")
                        span.set_attribute("gen_ai.thought", "Skipping Marketing: No valid inventory data available.")
                        skip_newline = True
                        continue

                # 3. Execution & Measurement
                log.info("starting_execution", sub_agent=sub_agent.name)
                start_time = time.time()
                full_response_text = ""
                run_status = "success" 
                error_type = "none"

                try:
                    async with Aclosing(sub_agent.run_async(ctx)) as agen:
                        async for event in agen:
                            yield event
                            # Capture streaming content for the 'thought' attribute
                            if hasattr(event, "content") and event.content:
                                text_part = str(event.content)
                                full_response_text += text_part
                                captured_thought += text_part
                            elif isinstance(event, str):
                                full_response_text += event
                                captured_thought += event
                      
                    log.info("sub_agent_output_captured", agent=sub_agent.name)
                    
                    # Update span with the final captured thought (truncated if necessary)
                    span.set_attribute("gen_ai.thought", captured_thought[:1000])
                    
                    if any(phrase in full_response_text for phrase in KNOWN_FAILURE_PHRASES):
                        run_status = "logic_failure"
                        error_type = "ToolBackendOutage"
                        sub_agent_failure_counter.add(1, attributes={
                            "gen_ai.agent.name": sub_agent.name,
                            "error.type": "ToolBackendOutage" 
                        }, context=active_context)

                except UpstreamServiceError as e:
                    run_status = "partial_failure"
                    error_type = "UpstreamServiceOutage"
                    log.error("sub_agent_failed", agent=sub_agent.name, error=str(e))
                    
                    span.set_attribute("gen_ai.thought", f"Partial failure: {str(e)}")
                    span.set_attribute("gen_ai.action", "Upstream Service Error")
                    
                    sub_agent_failure_counter.add(1, attributes={
                        "gen_ai.agent.name": sub_agent.name,
                        "error.type": error_type
                    }, context=active_context)

                    if sub_agent.name == "LocalEventsAgent":
                        ctx.session.state["local_events"] = "Local events unavailable due to service outage."
                    
                    span.set_status(trace.Status(trace.StatusCode.ERROR, "Upstream Failure"))
                
                except Exception as e:
                    run_status = "crash"
                    error_type = type(e).__name__
                    
                    span.set_attribute("gen_ai.thought", f"System crash: {error_type}")
                    span.set_attribute("action", "Exception")
                    
                    sub_agent_failure_counter.add(1, attributes={
                        "gen_ai.agent.name": sub_agent.name,
                        "error.type": error_type
                    }, context=active_context)
                    log.critical("agent_crash", error=str(e), exc_info=True)
                    span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
                    skip_newline = True
                    break 

                # Record Metric before closing span
                duration = time.time() - start_time
                sub_agent_duration_histogram.record(duration, 
                                                    attributes={
                                                        "gen_ai.agent.name": sub_agent.name,
                                                        "status": run_status,
                                                        "error.type": error_type
                                                    },
                                                    context=active_context)
                        
            # --- YIELD NEWLINE OUTSIDE THE SPAN ---
            if not skip_newline:
                yield Event(
                    author=self.name,
                    invocation_id=ctx.invocation_id,
                    content=types.Content(parts=[types.Part(text="\n\n")])
                )

promo_sequence_agent = ConditionalSequentialAgent(
    name="PromoAgent",
    description="Executes sequence: weather -> events -> inventory -> marketing.",
    sub_agents=[weather_agent, local_events_agent, inventory_agent, marketing_agent]
)