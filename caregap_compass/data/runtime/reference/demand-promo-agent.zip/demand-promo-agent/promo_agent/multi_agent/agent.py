# Copyright 2025 Google LLC
# Licensed under the Apache License, Version 2.0.

import os
import sys
import uuid
import asyncio
import structlog
import re
from dotenv import load_dotenv
load_dotenv()

from opentelemetry import metrics, trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.cloud_monitoring import CloudMonitoringMetricsExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter
from opentelemetry.trace import ProxyTracerProvider
from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
from opentelemetry.propagate import extract # <--- NEW IMPORT
from opentelemetry import context

from google.adk.agents import LlmAgent
from google.adk.models import LlmResponse
from google.adk.agents.callback_context import CallbackContext

from vertexai.preview import reasoning_engines
from .observability import configure_centralized_telemetry
configure_centralized_telemetry()

from .callbacks.modelarmor import model_armor_init_first_agent, model_armor_sanitize_request
from .sub_agents.promo_sequence_agent.promo_sequence_agent import promo_sequence_agent
instance_id = str(uuid.uuid4())
# --- CONFIGURE STRUCTLOG ---
logger = structlog.get_logger().bind(
    agent_name="GreetingAgent", 
    agent_id="greeting-001",
    instance_id=instance_id
)

GREETING_SYSTEM_PROMPT = """
You are a greeting agent. Your job is to take the most recent user prompt and decide if it is formed in the correct manner.

The prompt needs to be in this format: [US City] on [Day of Week]

US City: Can be any city in the US.
Day of Week: Cannot be the current day of the week, but can be any other day like Monday, Tuesday, etc.
Set hidden tag: "DETECTED_LOCATION: [US City]"
IMPORTANT: Only focus on the last user prompt. If the prompt does not meet the required format, then output the following message:

"Hello! I'm a promotional marketing agent that monitors local conditions such as weather and events, creates product suggestions based on current inventory, and automatically generates highly relevant promotional visuals for in-store displays or digital marketing channels.

Please provide the US City and Day of Week for the promotion in this format: [US City] on [Day of Week]

Eg: Seattle on Friday  [newline][newline]"

Once you are satisfied the format of the prompt is correct, output "Thank you! Generating promotion...\n\n" and run the promo_sequence_agent.

"""

def extract_city_and_day_pre_run(callback_context: CallbackContext):
    """
    Robustly extracts City and Day from user input BEFORE the agent runs.
    This ensures sub-agents have the context they need immediately.
    """
    # 1. Pull user input from various possible ADK locations
    user_input = ""
    if hasattr(callback_context, "input_text") and callback_context.input_text:
        user_input = callback_context.input_text
    elif hasattr(callback_context, "input") and callback_context.input:
        user_input = callback_context.input
        
    if not user_input:
        return

    # 2. Regex to match "[City] on [Day]" 
    # Logic: Look for any text followed by ' on ' followed by a day of the week
    pattern = r"^(.*)\s+on\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)"
    match = re.search(pattern, str(user_input).strip().lower(), re.IGNORECASE)

    if match:
        city_found = match.group(1).strip().title() # Format as 'Seattle'
        day_found = match.group(2).strip().title()
        
        # 3. Store in session state for all sub-agents to see
        callback_context.session.state["city"] = city_found
        callback_context.session.state["location"] = city_found
        callback_context.session.state["target_day"] = day_found
        
        logger.info("context_preloaded_successfully", city=city_found, day=day_found)


# --- AGENT DEFINITION ---
root_agent = LlmAgent(
    name="GreetingAgent",
    model="gemini-2.5-flash",
    instruction=GREETING_SYSTEM_PROMPT,
    output_key="greeting",
    sub_agents=[promo_sequence_agent],
    before_agent_callback=[model_armor_init_first_agent, extract_city_and_day_pre_run],
    before_model_callback=model_armor_sanitize_request
)

logger.info("agent_initialization_complete")

# --- WRAPPER CLASS ---
class GreetingAgentApp(reasoning_engines.ReasoningEngine):
    def __init__(self):
        self.agent = root_agent

    def query(self, **kwargs) -> dict:
        """
        Robust entry point.
        """
        try:
            # --- 1. ATTEMPT TO RESTORE TRACE CONTEXT ---
            # Vertex AI/Cloud Run injects 'x-cloud-trace-context' or 'traceparent' headers.
            # They might be in os.environ or kwargs depending on the runtime wrapper.
            
            # Helper to normalize headers from kwargs if present
            headers = {}
            if "headers" in kwargs:
                headers = kwargs["headers"]
            
            # Extract context from headers (OpenTelemetry handles X-Cloud-Trace-Context automatically)
            ctx = extract(headers)
            
            # If nothing found in headers, check Environment (Common in Cloud Run)
            if not ctx:
                ctx = extract(os.environ)

            # --- 2. RUN WITH ACTIVE CONTEXT ---
            # We wrap the execution in the extracted context.
            token = context.attach(ctx)
            try:
                user_input = kwargs.get("input") or kwargs.get("message") or kwargs.get("prompt")
                
                if isinstance(user_input, dict):
                     user_input = user_input.get("input") or user_input.get("message")

                if not user_input:
                    return {"error": "No valid input found", "received": kwargs}

                # Now this runs WITH the Platform's Trace ID
                response = asyncio.run(self.agent.run_async(user_input))
                return {"output": response.text}
                
            finally:
                context.detach(token)

        except Exception as e:
            logger.error("query_failed", error=str(e))
            return {"error": str(e)}