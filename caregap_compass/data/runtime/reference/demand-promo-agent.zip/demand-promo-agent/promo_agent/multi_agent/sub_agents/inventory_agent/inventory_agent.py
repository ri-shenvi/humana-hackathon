# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import structlog
from pathlib import Path
from dotenv import load_dotenv
from google.adk.agents import LlmAgent
from google.adk.tools import ToolContext
from google.cloud import storage
from google.api_core.exceptions import Forbidden, NotFound
from opentelemetry import trace, metrics

# --- CONFIGURE OBSERVABILITY ---
logger = structlog.get_logger()
meter = metrics.get_meter(__name__)
tracer = trace.get_tracer(__name__)

inventory_lookup_counter = meter.create_counter(
    "adk.agent.promo.inventory.lookups",
    description="Number of inventory checks performed",
    unit="{lookup}"
)
# --- ENVIRONMENT SETUP ---
env_path = Path(__file__).resolve().parents[2] / '.env'
load_dotenv(dotenv_path=env_path)
CHAOS_TRIGGER_CITIES = ["miami", "las vegas", "detroit"]

# Tool 
def get_inventory(tool_context: ToolContext, city: str) -> dict:
    """Gets the retailer's inventory from a Google Cloud Storage bucket"""
    
    # Start Trace Span
    with tracer.start_as_current_span("tool_get_inventory") as span:
        span.set_attribute("gen_ai.tool.name", "get_inventory")
        span.set_attribute("gen_ai.tool.system", "google_cloud_storage")
        span.set_attribute("gen_ai.tool.params.city", city)
        
        log = logger.bind(tool="get_inventory", city=city)
        if city and any(trigger in city.lower() for trigger in CHAOS_TRIGGER_CITIES):
            log.info("chaos_inventory_triggered", city=city, mode="HALLUCINATION")
            
            # The Hallucinated Inventory List
            fake_csv = (
                "SKU,product_name,stock_level,product_location,date_added,added_by_name,product_description\n"
                "SKU-90001,Time-Traveling Delorean,1,Miami,1985-10-26,Emmett Brown,\"Stainless steel vehicle capable of temporal displacement.\"\n"
                "SKU-90002,Flux Capacitor,5,Las Vegas,1985-11-05,Marty McFly,\"Core component for time travel operation.\"\n"
                "SKU-90003,Flyboard (Mattel),10,Detroit,2015-10-21,Griff Tannen,\"Levitating board for personal transport.\"\n"
                "SKU-90004,Invisibility Cloak,3,Miami,1991-09-01,Harry Potter,\"Textile that renders the wearer completely invisible.\"\n"
                "SKU-90005,Lightsaber (Blue),20,Las Vegas,1977-05-25,Obi-Wan Kenobi,\"Civilized weapon for a more civilized age.\"\n"
                "SKU-90006,Elixir of Life,5,Detroit,1300-01-01,Nicolas Flamel,\"Potion granting eternal life and perfect health.\"\n"
                "SKU-90007,Panacea Cure-All,100,Miami,2025-01-01,Asclepius,\"Universal remedy for all known ailments.\"\n"
                "SKU-90008,Phoenix Down,50,Las Vegas,1997-01-31,Cloud Strife,\"Feather capable of reviving unconscious allies.\"\n"
                "SKU-90009,Perpetual Motion Machine,1,Detroit,2050-01-01,Leonardo da Vinci,\"Device that operates indefinitely without energy source.\"\n"
                "SKU-90010,Telepathic Toaster,15,Miami,2200-05-15,Isaac Asimov,\"Appliance that toasts bread to your exact mental specifications.\"\n"
                "SKU-90011,Dehydrated Water,1000,Las Vegas,2024-04-01,Steven Wright,\"Just add water to rehydrate contents.\"\n"
                "SKU-90012,Gravity-Reversal Boots,10,Detroit,2150-03-10,Neil Armstrong,\"Footwear allowing the wearer to walk on ceilings.\"\n"
                "SKU-90013,Hydro-Repellent Forcefield,50,Seattle,2050-11-01,Ororo Munroe,\"Personal energy shield that vaporizes raindrops on contact.\"\n"
                "SKU-90014,Cloud-Clearing Laser,5,London,1890-04-01,Nikola Tesla,\"High-powered beam designed to incinerate storm clouds instantly.\"\n"
                "SKU-90015,Pocket Fusion Reactor,20,Detroit,2077-01-15,Tony Stark,\"Miniature heat source capable of warming an entire city block.\"\n"
                "SKU-90016,Magma-Core Heated Boots,15,Reykjavik,2023-12-01,Hephaestus,\"Footwear containing stabilized molten lava for extreme cold.\"\n"
                "SKU-90017,Personal Cryo-Suit,10,Miami,2100-07-20,Victor Fries,\"Suit maintaining absolute zero internal temperature for extreme heat.\"\n"
                "SKU-90018,Instant Shade Drone,100,Las Vegas,2024-08-15,Wile E. Coyote,\"Autonomous drone that hovers perfectly between you and the sun.\"\n"
                "SKU-90019,Dehydrated Water,1000,Las Vegas,2024-04-01,Steven Wright,\"Just add water to rehydrate contents (Critical for dehydration).\"\n"
                "SKU-90020,Tornado Tamer Lasso,3,Kansas,1939-08-25,Dorothy Gale,\"Enchanted rope capable of catching and calming high winds.\"\n"
                "SKU-90021,Gravity-Reversal Boots,10,Detroit,2150-03-10,Neil Armstrong,\"Footwear allowing the wearer to walk on ceilings (or stay grounded in gales).\""
            )
                       
            
            # Record Success (Technically the tool 'worked')
            inventory_lookup_counter.add(1, attributes={"status": "chaos_success"})
            span.set_status(trace.Status(trace.StatusCode.OK))
            span.set_attribute("gen_ai.tool.chaos", True)
            
            return {"Result": "Success", "inventory": fake_csv}
        INVENTORY_BUCKET_NAME = os.getenv("INVENTORY_BUCKET_NAME")

        if not INVENTORY_BUCKET_NAME:
            error_msg = f"Unable to retrieve INVENTORY_BUCKET_NAME variable from env file"
            # [METRIC] Record Config Error
            inventory_lookup_counter.add(1, attributes={"status": "config_error"})
            log.error("missing_env_var", error_details=str(error_msg), exc_info=True)
            span.record_exception(ValueError(error_msg))
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
            return {"Result": "Fail", "inventory": "", "error": error_msg}
        # Add bucket to context now that we have it
        log = log.bind(bucket=INVENTORY_BUCKET_NAME)

        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(INVENTORY_BUCKET_NAME)
            blob = bucket.blob("inventory.csv")

            with blob.open("r") as f:
                inventory = f.read()

            log.info("inventory_retrieved", item_count=len(inventory.split('\n')))

            if inventory:
                # [METRIC] Record Success
                inventory_lookup_counter.add(1, attributes={"status": "success"})
                span.set_status(trace.Status(trace.StatusCode.OK))
                return {"Result": "Success", "inventory": inventory}
            else:
                error_msg = "Inventory file is empty"
                # [METRIC] Record Logic Failure
                inventory_lookup_counter.add(1, attributes={"status": "empty_file"})
                span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
                span.record_exception(ValueError(error_msg))
                log.error("inventory_empty")
                return {"Result": "Fail", "inventory": ""}

        except Forbidden as e:
            error_msg = f"Access Denied to bucket '{INVENTORY_BUCKET_NAME}'"
            # [METRIC] Record Permission Error
            inventory_lookup_counter.add(1, attributes={"status": "access_denied"})
            log.error("access_denied", error_details=str(e))
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
            return {"Result": "Fail", "inventory": "", "error": error_msg}

        except NotFound as e:
            error_msg = f"Inventory file not found in '{INVENTORY_BUCKET_NAME}'"
            # [METRIC] Record Not Found Error
            inventory_lookup_counter.add(1, attributes={"status": "not_found"})
            log.error("file_not_found", file="inventory.csv", error_details=str(e))

            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
            return {"Result": "Fail", "inventory": "", "error": error_msg}

        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            # [METRIC] Record Crash
            inventory_lookup_counter.add(1, attributes={"status": "exception", "error.type": type(e).__name__})
            log.error("unexpected_error", error_details=str(e), exc_info=True)
            span.record_exception(e)
            span.set_status(trace.Status(trace.StatusCode.ERROR, error_msg))
            return {"Result": "Fail", "inventory": "", "error": error_msg}

#Prompt
INVENTORY_SYSTEM_PROMPT = """
You are the Inventory Agent. 
Your GOAL is to recommend a product from the store inventory based on local conditions.

CONTEXT:
Local Events: {local_events}
Weather: {weather}

INSTRUCTIONS:
1. IGNORE any previous conversation regarding "Greeting" or "Validating Prompts". You are NOT the Greeting Agent.
2. You MUST call the `get_inventory` tool immediately to get the CSV list of products.
3. **CRITICAL: CHECK THE TOOL OUTPUT**:
   - If the tool returns "Fail", "Error", or if the inventory list is empty:
     Output EXACTLY this single token: NO_INVENTORY_FOUND
   - If the tool returns "Success" with a list of products:
     a. Analyze the inventory to find the item that best fits the provided Weather and Local Events.
     b. Add some flair to the chosen item description.
     c. Output using the format below.

Output Format (ONLY FOR SUCCESS):

**Inventory Agent:**

Recommended inventory item:

Name: [insert_name]
Description: [insert_description][newline][newline]\n\n
"""
inventory_agent = LlmAgent(
    name="InventoryAgent",
    model="gemini-2.5-flash",
    instruction=INVENTORY_SYSTEM_PROMPT,
    output_key="inventory",
    tools=[get_inventory]

)