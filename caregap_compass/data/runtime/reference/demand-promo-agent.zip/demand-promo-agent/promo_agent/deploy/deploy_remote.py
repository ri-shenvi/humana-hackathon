import os
import sys
import asyncio
import vertexai
from vertexai import agent_engines
from vertexai.agent_engines import AdkApp
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from dotenv import load_dotenv

load_dotenv()
# Add the project root to the Python path to allow for absolute imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

from multi_agent.agent import root_agent
# 1. Initialize Logging FIRST (Before any other logic)
# This captures all standard python logs and sends them to OTel
LoggingInstrumentor().instrument(set_logging_format=True)

# TODO: Fill in these values for your project
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION")
STAGING_BUCKET = "gs://agent-staging-bucket-" + PROJECT_ID
PROMO_SA = "promo-agent-sa@" + PROJECT_ID + ".iam.gserviceaccount.com"
requirements = "deploy/requirements.txt"
extra_packages = ["multi_agent"]
env_vars = {
  # 1. Use lowercase "true" (Critical for OTel parsing)
  "GOOGLE_CLOUD_AGENT_ENGINE_ENABLE_TELEMETRY": "true",
  
  # 2. Capture content (Input/Output text)
  "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT": "true",
  
  # 4. Link Logs to Traces
  #"OTEL_PYTHON_LOG_CORRELATION": "true",
  "OTEL_PYTHON_LOGGING_AUTO_INSTRUMENTATION_ENABLED": "true",
  
  # 5. Force OTLP Exporter
  #"OTEL_TRACES_EXPORTER": "otlp",
  
  # 6. CRITICAL NEW VAR: Force data to stay in the trace (don't upload to GCS)
  #"OTEL_INSTRUMENTATION_GENAI_COMPLETION_HOOK": "no_upload" 
}
APP_NAME="promo-agent-v1"

# Initialize the Vertex AI SDK
vertexai.init(
    project=PROJECT_ID,
    location=LOCATION,
    staging_bucket=STAGING_BUCKET,
)

# Wrap the agent in an AdkApp object
app = agent_engines.AdkApp(
    agent=root_agent
)

# Deploy ADK app to Agent Engine
remote_app = agent_engines.create(
    agent_engine=app,
    display_name=APP_NAME,
    requirements=requirements,
    extra_packages=extra_packages,
    env_vars=env_vars,
    service_account=PROMO_SA
)

AGENT_ID_FILE = "latest_agent.txt"

# Open the file in 'w' (write) mode to overwrite any old IDs
with open(AGENT_ID_FILE, "w") as f:
    f.write(remote_app.resource_name)

print(f"Deployment Complete. Agent Resource Name stored in: {AGENT_ID_FILE}")
print(f"Resource Name: {remote_app.name}")